package com.alianhome.galleryscreenshot;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;

import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerNativeActivity;

/* 
 * 	�޸���־
 * 	2016��8��4��10:27:11
 * 	 1. �޸�����ͬһ��ͼƬ��ʱ�� ��ɵ�BUG  SqlLite ������ͬ���� ������ 
 * 	 2. ÿ�α���ͼ����Ҫһ���µ�����	
 *   3. ÿ��ͼ�񱣴�������Ե�ǰ��ʱ��������
 * 
 * 
 * 
 */

public class MainActivity extends UnityPlayerNativeActivity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	private static String TAG = "Gallery Screenshot";
	private static String lastImageFilePath = "";
	private static String LastVideoFilePath="";
	

	
	
	/**
	 * ������Ƶ�����
	 * 
	 * @param path
	 *            ͼƬ��ɳ��·��
	 */
	public static void addVideoToGallery(final String path) {
		if (LastVideoFilePath == path) {
			return;
		} else {
			LastVideoFilePath = path;
		}

		new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub

				String cameraFilePath = path;

				try {
					UnityPlayer.UnitySendMessage("GalleryScreenshotBridgeLink", "GalleryScreenshotStateChange", "Start");
					@SuppressWarnings("resource")
					FileInputStream inputStream = new FileInputStream(path);
					// ƴ�����ĸ�·��
					String fileNamePath = Environment.getExternalStorageDirectory().getPath() + File.separator + Environment.DIRECTORY_DCIM + File.separator + "Camera" + File.separator;
					Calendar calendar = Calendar.getInstance();

					int year = calendar.get(Calendar.YEAR);
					int month = calendar.get(Calendar.MONTH);
					int day = calendar.get(Calendar.DATE);
					int hour = calendar.get(Calendar.HOUR);
					int minute = calendar.get(Calendar.MINUTE);
					int second = calendar.get(Calendar.SECOND);
					String filename = String.format("%d%d%d%d%d%d", year, month, day, hour, minute, second);
					cameraFilePath = fileNamePath + filename + ".mp4";
					@SuppressWarnings("resource")
					FileOutputStream fileOutputStream = new FileOutputStream(cameraFilePath);

					int in;
					byte[] buffer = new byte[1024 * 10];

					in = inputStream.read(buffer);
					// Log.i(TAG, "A");
					while (in != -1) {
						// Log.i(TAG, " ��ȡ����  " + String.valueOf(in));
						fileOutputStream.write(buffer, 0, in);
						in = inputStream.read(buffer);
					}
					// Log.i(TAG, "B");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// Log.i(TAG, "C");
				File file = new File(cameraFilePath);
				// Log.i(TAG, "D");
				if (file.exists()) {
					// Log.i(TAG, "E");
					ContentValues values = new ContentValues();
					long systemtime =System.currentTimeMillis();
					// ������֤
					values.put("datetaken", Long.valueOf(systemtime));
					// ����
					values.put("mime_type", "video/mp4");
					// ����Դ
					values.put("_data", file.getAbsolutePath());
					
//					values.put("title", file.getName());
//					values.put("_display_name", file.getName());
//					values.put("date_modified", Long.valueOf(systemtime));
//					values.put("date_added", Long.valueOf(systemtime));
//					values.put("_size", Long.valueOf(file.length()));
					
					// Log.i(TAG, "F");
					// ����
					values.put(MediaStore.Video.VideoColumns.TITLE, file.getName());
					// Log.i(TAG, "G");
					// ����
					Uri uri = UnityPlayer.currentActivity.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);

					values.clear();
					// Log.i(TAG, "H");
					values.put(MediaStore.Video.Media.EXTERNAL_CONTENT_URI.toString(), new File(cameraFilePath).length());
					// Log.i(TAG, "I");
					//UnityPlayer.currentActivity.getContentResolver().update(uri, values, null, null);
					// Log.i(TAG, "J");
					UnityPlayer.currentActivity.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.parse("file://" + cameraFilePath)));

					UnityPlayer.UnitySendMessage("GalleryScreenshotBridgeLink", "GalleryScreenshotStateChange", "Finish");
					Log.i(TAG, "Content values written for file " + file.getAbsolutePath());
				}
			}

		}).start();
	}


	/**
	 * ����ͼƬ�����
	 * 
	 * @param path
	 *            ͼƬ��ɳ��·��
	 */
	public static void addImageToGallery(final String path) {
		if (lastImageFilePath == path) {
			return;
		} else {
			lastImageFilePath = path;
		}

		new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub

				String cameraFilePath = path;

				try {
					UnityPlayer.UnitySendMessage("GalleryScreenshotBridgeLink", "GalleryScreenshotStateChange", "Start");
					@SuppressWarnings("resource")
					FileInputStream inputStream = new FileInputStream(path);
					// ƴ�����ĸ�·��
					String fileNamePath = Environment.getExternalStorageDirectory().getPath() + File.separator + Environment.DIRECTORY_DCIM + File.separator + "Camera" + File.separator;
					Calendar calendar = Calendar.getInstance();

					int year = calendar.get(Calendar.YEAR);
					int month = calendar.get(Calendar.MONTH);
					int day = calendar.get(Calendar.DATE);
					int hour = calendar.get(Calendar.HOUR);
					int minute = calendar.get(Calendar.MINUTE);
					int second = calendar.get(Calendar.SECOND);
					String filename = String.format("%d%d%d%d%d%d", year, month, day, hour, minute, second);
					cameraFilePath = fileNamePath + filename + ".png";
					@SuppressWarnings("resource")
					FileOutputStream fileOutputStream = new FileOutputStream(cameraFilePath);

					int in;
					byte[] buffer = new byte[1024 * 10];

					in = inputStream.read(buffer);
					// Log.i(TAG, "A");
					while (in != -1) {
						// Log.i(TAG, " ��ȡ����  " + String.valueOf(in));
						fileOutputStream.write(buffer, 0, in);
						in = inputStream.read(buffer);
					}
					// Log.i(TAG, "B");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// Log.i(TAG, "C");
				File file = new File(cameraFilePath);
				// Log.i(TAG, "D");
				if (file.exists()) {
					// Log.i(TAG, "E");
					ContentValues values = new ContentValues();

					// ������֤
					values.put("datetaken", Long.valueOf(System.currentTimeMillis()));
					// ����
					values.put("mime_type", "image/png");
					// ����Դ
					values.put("_data", file.getAbsolutePath());
					// Log.i(TAG, "F");
					// ����
					values.put(MediaStore.Images.ImageColumns.TITLE, file.getName());
					// Log.i(TAG, "G");
					// ����
					Uri uri = UnityPlayer.currentActivity.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

					values.clear();
					// Log.i(TAG, "H");
					values.put(MediaStore.Images.ImageColumns.SIZE, new File(cameraFilePath).length());
					// Log.i(TAG, "I");
					UnityPlayer.currentActivity.getContentResolver().update(uri, values, null, null);
					// Log.i(TAG, "J");
					UnityPlayer.currentActivity.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.parse("file://" + cameraFilePath)));

					UnityPlayer.UnitySendMessage("GalleryScreenshotBridgeLink", "GalleryScreenshotStateChange", "Finish");
					Log.e("Gallery Screenshot", "Content values written for file " + file.getAbsolutePath());
				}
			}

		}).start();
	}


}
